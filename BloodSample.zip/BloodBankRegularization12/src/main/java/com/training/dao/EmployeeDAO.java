package com.training.dao;

import java.util.List;

import com.training.model.Employees;

public interface EmployeeDAO {

	
	/** 
	    * This is the method to be used to list down
	    * a record from the Student table corresponding
	    * to a passed student id.
	    */
	   public List<Employees> getEmployees(String bloodGroup);
	   public void updateEmployees(Employees emp);
	   public void postEmployees(Employees emp);
	   public void deleteEmployees(Integer id);
	   public List<Employees> getallEmployees();
}
