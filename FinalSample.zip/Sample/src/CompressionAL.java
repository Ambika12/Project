import java.util.ArrayList; 
import java.util.HashSet;  
public class CompressionAL { 
        public static void main(String[] args) { 
                String a = "aaabbccdda"; 
                int count = 0; 
                String result = ""; 
                System.out.println(a); 
                ArrayList<Character> hs = new ArrayList<Character>(); 
                for (int i = 0; i < a.length(); i++) { 
                        hs.add(a.charAt(i) ); 
                } 
                for (int i = 0; i < hs.size(); i++) { 
                        count = 1; 
                        char temp = hs.get(i) ; 
                        result = result + temp; 
                        for (int j = i + 1; j < hs.size(); j++) { 
                                if (temp == hs.get(j)) { 
                                        count++; 
                                } else { 
                                        break; 
                                } 
                        } 
                        if (count != 1) { 
                                result = result + count; 
                        } 
                        i = i + count - 1; 
                } 
                System.out.println(result); 
        } 
}
