package com.bny.dao;

import java.util.List;

import com.bny.bean.Employee;


public interface IEmployeeDao 
{
	   //view details by using id
	
		public Employee getEmployeeById(int emp_id);
		
		//view details by using list
		
		public List<Employee> getEmployees();
		
		//Insert details

		public Employee insertEmployee(Employee employee);
		
		//Delete details
		
		public Employee deleteEmployee(int emp_id);
		
		//update details

		public Employee updateEmployee(int emp_id);
		

}


