
public class withoutString {
	public static String FindWithoutString(String base, String remove) {
		   String res="";

		  int i=0;
		  
		  
		  while(i<=(base.length()-remove.length())){
			  
			  
		  if(base.substring(i,i+remove.length()).equalsIgnoreCase(remove))
		    
		  {
		     i=i+remove.length();  // move to next set of strings to check if it matches "remove"
		     continue;
		     
		  }
		     res=res+base.charAt(i);  //append if not
		     i++;
		  }
		  res=res+base.substring(i);
		  
		  return res;
		}
	
	public static void main(String args[])
	{
		String b="Hello there";
		String r="llo";
		String result=FindWithoutString(b,r);
		System.out.println(result);
	}

}
