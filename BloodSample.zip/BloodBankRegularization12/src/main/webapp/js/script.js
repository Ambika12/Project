var app=angular.module('myApp',['ngRoute']);
         
app.config(function($routeProvider){
                $routeProvider.
                when('/', {templateUrl:'login.html'
                	}).
                when('/mainPage', {templateUrl:'mainPage.html',
                	controller: 'EmpCont'}).
                when('/register', {
                templateUrl:'register.html',
                controller: 'EmpController'
                }). 
              when('/forgotpassword', {
                templateUrl:'forgotpassword.html'}).
                otherwise({redirectTo : '/'});
		});
app.controller('EmpCont', function($scope, $http) {
       $scope.showMe=false; 
  $scope.getDonor=function(){
      $http.get("/BloodBankRegularization/employees")
        .success(function(response) {
     	   $scope.showMe=!$scope.showMe;
     	   $scope.showErr=false;
     	   $scope.names = response;
     	   });
    
      }
  $scope.getSpecificDonor=function(){
	  $http.get("/BloodBankRegularization/employees/"+$scope.bloodGroup)
	    .success(function(response) {
	    	  $scope.showMe=!$scope.showMe;
	    	  $scope.showErr=false;
	    	$scope.names = response;})
	  .error(function(response) {
	      if(response.status!=200)
	      {
	    	  $scope.showErr=true;
	    	  $scope.showMe=false;

	     $scope.text='No employee with that blood group';  }
	});
	  }
  $scope.updateIt=function(){
	  var mobj={
			  id : $scope.id,
			  name : $scope.name,
			  password : $scope.password,
			  email : $scope.email,
			  phoneNo : $scope.phoneNo,
			  bloodGroup : $scope.bloodGroup
	  };
      $http.put("/BloodBankRegularization/employees/"+$scope.id,mobj)
      .success(function(response) {$scope.message = response; 
      $scope.text="record updated..";
      })
     ;
  }
  $scope.deleteEmp = function(id) {
      $http({
          method : 'DELETE',
          url : 'employees/'+ $scope.id
      
		});
  }
  $scope.reset=function()
  {
	  $scope.id="";
	  $scope.name="";
	  $scope.email="";
	  $scope.phoneNo="";
	  $scope.bloodGroup="";
  }
});

  app.controller('EmpController', function($scope, $http) {
      $scope.showMe=false; 
	  $scope.insert=function(){
		$http({
			method: 'POST',
			url : '/BloodBankRegularization/employees' ,
			data : { 
				id : $scope.id,
				  name : $scope.name,
				  password : $scope.password,
				  email : $scope.email,
				  phoneNo : $scope.phoneNo,
				  bloodGroup : $scope.bloodGroup
				  
			}
			}) .success(function(response) {$scope.message = response; 
			alert(" record created");
			});
		
		
	 
    
 }
 });