import java.io.*;
import java.util.*;
public class sumDigits {
	
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the String");
	String stri=sc.next();
	int result=sumD(stri);
	System.out.println(result);
	}
	public static int sumD(String str)
	{
	int sum = 0;
 	int lim = str.length();
  char ch;
  for(int i = 0; i < lim; i++)
  {
  	ch = str.charAt(i);
		if(Character.isDigit(ch)) // or simply (ch >= '0' && ch <= '9')
			sum += (ch - '0');
	}
	return sum;
}
}
