package com.bny.EmployeeController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bny.bean.Employee;
import com.bny.daoImpl.EmployeesJDBCTemplate;

@RestController
public class EmployeeController
{
	
	@Autowired
	EmployeesJDBCTemplate employeeDAO;


	/*@RequestMapping(value = "employees", method = RequestMethod.GET)
	public @ResponseBody String getEmployeeById1() {
		System.out.println("success");
		return "good";
		

	}*/

	
	// select

	@RequestMapping(value = "employees/{emp_id}", method = RequestMethod.GET)
	public @ResponseBody Employee getEmployeeById(@PathVariable("emp_id") int emp_id)
	{
		Employee employee = employeeDAO.getEmployeeById(emp_id);
		return employee;

	}
	
	
	//view in list
	
	@RequestMapping(value="/employees" , method = RequestMethod.GET)

    public List<Employee> getEmployees()
	{    

            List <Employee> employeeList1 = new ArrayList<Employee>();

            List<Employee> employeeList2 = new ArrayList<Employee>();

            employeeList1 = employeeDAO.getEmployees();

            employeeList2.addAll(employeeList1);

            return employeeList2;

    }



	// insert
	@RequestMapping(value = "employees", method = RequestMethod.POST)
	public @ResponseBody Employee insertEmployee(@RequestBody Employee employee)
	{
		employeeDAO.insertEmployee(employee);
		return employee;

	}

	// update

	@RequestMapping(value = "employees", method = RequestMethod.PUT)
	public @ResponseBody Employee updateEmployee(@PathVariable("emp_id") int emp_id) 
	{
		Employee employee = employeeDAO.updateEmployee(emp_id);
		return employee;

	}

	// delete

	@RequestMapping(value = "employees", method = RequestMethod.DELETE)
	public @ResponseBody Employee deleteEmployee(@PathVariable("emp_id") int emp_id)
	{
		Employee employee = employeeDAO.deleteEmployee(emp_id);
		return employee;

	}

}
