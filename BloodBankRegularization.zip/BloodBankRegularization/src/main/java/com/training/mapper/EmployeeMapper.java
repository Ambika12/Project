package com.training.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.model.Employees;

public class EmployeeMapper implements RowMapper<Employees> {

	public Employees mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employees emp = new Employees();
		emp.setId(rs.getInt("id"));
		emp.setName(rs.getString("name"));
		emp.setPassword(rs.getString("password"));
		emp.setEmail(rs.getString("email"));
		emp.setBloodGroup(rs.getString("bloodGroup"));
		emp.setPhoneNo(rs.getString("phoneNo"));
	      return emp;
	   }
	
}
