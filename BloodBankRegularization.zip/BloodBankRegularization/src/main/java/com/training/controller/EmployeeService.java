package com.training.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.training.daoimpl.EmployeesJDBCTemplate;
import com.training.model.Employees;


@RestController
public class EmployeeService {

	@Autowired
	EmployeesJDBCTemplate EmployeeDAOImpl;


    @RequestMapping(value="employees/{bloodGroup}", method = RequestMethod.GET)
    public List getEmployees(@PathVariable("bloodGroup") String bloodGroup){
    	List<Employees> employee = EmployeeDAOImpl.getEmployees(bloodGroup);
    	System.out.println(bloodGroup);
		if(employee==null)
		{
			Employees emp=new Employees();
			emp.setId(null);
			emp.setEmail(null);
			emp.setName(null);
			emp.setPhoneNo(null);
			emp.setBloodGroup(null);
			
			employee.add(emp);
		}
			
		else
		{
			//employee.add(employee);
		}
			
      return employee;
    }
    @RequestMapping(value="/employees", method = RequestMethod.POST)
    public String postEmployees(@RequestBody Employees emp){
    	EmployeeDAOImpl.postEmployees(emp);
      return "A New record is created successfully";
    }
    
    @RequestMapping(value="/employees/{id}", method = RequestMethod.PUT)
    public String updateEmployees(@RequestBody Employees emp,@PathVariable("id") int id){
    	emp.setId(id);
    	EmployeeDAOImpl.updateEmployees(emp);
      return "Record is updated";
    }
    
    @RequestMapping(value="/employees/{id}", method = RequestMethod.DELETE)
    public String deleteEmployees(@PathVariable("id") int id){
       EmployeeDAOImpl.deleteEmployees(id);
           return "record is deleted";
    }
    
    @RequestMapping(value="employees", method = RequestMethod.GET)
    public List getallEmployees(){
    	//List l=new ArrayList();
		List<Employees> employee = EmployeeDAOImpl.getallEmployees();
		if(employee==null)
		{
			Employees emp=new Employees();
			emp.setId(null);
			emp.setEmail(null);
			emp.setName(null);
			emp.setPhoneNo(null);
			emp.setBloodGroup(null);
			employee.add(emp);
		}
			
		
			
      return employee;
    }

    
}
