package com.bny.bean;

public class Department
{

	/*DEPT_ID   NUMBER PRIMARY KEY
DEPT_NAME VARCHAR (120)
*/
	String dept_name;
	int dept_id;
	public int getDept_id() 
	{
		return dept_id;
	}
	public void setDept_id(int dept_id)
	{
		this.dept_id = dept_id;
	}
	public String getDept_name() 
	{
		return dept_name;
	}
	public void setDept_name(String dept_name) 
	{
		this.dept_name = dept_name;
	}
}
