
public class equalIsNot {
	public static boolean FindEqualIsNot(String str) {
		   int balance = 0;
			  int p;
			  p = str.indexOf("is");
			  while(p != -1)
			  {
					balance++;
				  p = str.indexOf("is", p+2);
				}
				p = str.indexOf("not");
			  while(p != -1)
			  {
					balance--;
				  p = str.indexOf("not", p+3);
				}
				return (balance == 0);
		}

	public static void main(String args[])
	{
		String s="This is not";
		System.out.println(FindEqualIsNot(s));
		
	}
}
