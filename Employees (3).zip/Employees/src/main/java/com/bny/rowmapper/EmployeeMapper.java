package com.bny.rowmapper;



import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bny.bean.Employee;

public class EmployeeMapper implements RowMapper<Employee> 
{

	public Employee mapRow(ResultSet rs, int arg1) throws SQLException
	{
		
		Employee employee=new Employee();
		employee.setEmp_id(rs.getInt(1));
		employee.setEmp_name(rs.getString(2));
		employee.setDOB(rs.getDate(3));
		employee.setDesignation(rs.getString(4));
		employee.setDept_id(rs.getInt(5));
		
		return employee;
		
	}

}

