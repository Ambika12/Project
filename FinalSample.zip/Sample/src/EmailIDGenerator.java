
public class EmailIDGenerator {

}
