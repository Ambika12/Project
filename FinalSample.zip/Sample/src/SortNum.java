import java.util.Arrays;
import java.util.Scanner;

public class SortNum {

       public static void main(String[] args) {
              // TODO Auto-generated method stub
              Scanner sc=new Scanner(System.in);
              int arr[]=new int[6];
              int count=0,count1=0,temp=0;
              for(int i=0;i<6;i++) {
                     arr[i]=sc.nextInt();
                     if(arr[i]>=0) 
                           count++;
                     if(arr[i]<0)
                           count1++;
              }
              System.out.println(count+" "+ count1);
              //sort
              for(int i=0;i<arr.length-1;i++) 
        {
            for(int j=i+1;j<arr.length;j++)
            {
                if(arr[i]>arr[j]) 
                   {
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                   }
            }
        }
              //for(int i=0;i<6;i++) 
                     //System.out.println(arr[i]);
              int a[]=new int[count];
              int b[]=new int[count1];
              int j=count1;
              for(int i=0;i<count;i++) {
                     if(arr[j]>=0) {
                           a[i]=arr[j];
                     //     j++;
                     }
                     j++;
              }
              j=0;
              for(int i=0;i<count1;i++) {
                     if(arr[j]<0) {
                           b[i]=arr[j];
                           //j++;
                     }
                     j++;
       }
              
              for(int i=0;i<6;i++) {
                     if(count>0) {
                           System.out.println(a[i]);
                           count--;
                     }
                     if(count1>0) {
                           System.out.println(b[i]);
                           count1--;
                     }
              }
       //System.out.println(Arrays.toString(a));
              
       }

}


