import java.io.*;
import java.util.*;

public class Anagrams1 {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the first String ");
	String a=sc.next();
	System.out.println("Enter the second String ");
	String b=sc.next();
	sc.close();
	boolean ret=isAnagrams(a,b);

System.out.println(ret? "Anagrams": "Not Anagrams");
}

public static boolean isAnagrams(String c,String d)
{
	String a1=c.replaceAll(" ", "");
	String b1=d.replaceAll(" ", "");
	
	
if(a1.length()!=b1.length())
{
	return false;
}

char[] arr1=a1.toLowerCase().toCharArray();
char[] arr2=b1.toLowerCase().toCharArray();
System.out.println(arr1);
Arrays.sort(arr1);
System.out.println(arr1);
Arrays.sort(arr2);

return Arrays.equals(arr1, arr2);

}
}
