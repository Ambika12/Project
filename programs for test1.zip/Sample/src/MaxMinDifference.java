import java.util.Scanner;

public class MaxMinDifference
{
       public static void main(String args[])
       {
              Scanner sc=new Scanner(System.in);
              int i,dif=0,max,min; 
              System.out.println("Enter the array no:");
              int n=sc.nextInt();
              int[] arr=new int[n];
              
              System.out.println("Enter the array:");

              for(i=0;i<n;i++)
              {
                     arr[i]=sc.nextInt();
              }
              max=arr[0];
              min=arr[0];
              for(i=1;i<arr.length;i++)
              {
              if(arr[i]>max)
                     max=arr[i];
              if(arr[i]<min)
                     min=arr[i];
             

              }
              System.out.println(max);
              System.out.println(min);
       dif=max-min;

       System.out.println(dif);

       }
}

