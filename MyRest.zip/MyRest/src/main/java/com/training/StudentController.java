package com.training;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;





@Controller
public class StudentController {
	
	//Map to store employees, ideally we should use database
	Map<Integer, Student> studentData = new HashMap<Integer, Student>();



	@RequestMapping(value = "/students/dummy", method = RequestMethod.GET)
	public @ResponseBody Student getDummyStudent() {
		
		Student student = new Student();
		student.setId(9999);
		student.setName("Dummy");
		student.setAge(25);
		studentData.put(9999, student);
		student.setMsg("Dummy value");
		return student;
	}
	
	
	
	@RequestMapping(value = "/students/{id}", method = RequestMethod.GET)
	public @ResponseBody Student getStudent(@PathVariable("id") int studentId) {
		
		Student student=new Student();
		if(studentData.containsKey(studentId)){
			student=studentData.get(studentId);
		student.setMsg("Retrieved value");
		}
		else{
			student.setMsg("Student id not found");
			
		}
		return student;
			
					
	}
	
	@RequestMapping(value = "/students", method = RequestMethod.GET)
	public @ResponseBody List<Student> getAllStudents() {
		
		List<Student> students = new ArrayList<Student>();
		Set<Integer> studentIdKeys = studentData.keySet();
		for(Integer i : studentIdKeys){
			students.add(studentData.get(i));
		}
		return students;
	}
	
	
	
	@RequestMapping(value = "/students", method = RequestMethod.POST)
	public @ResponseBody Student createStudent(@RequestBody Student student) {
		
		if(studentData.containsKey(student.getId())){
			student.setMsg("Student id already exists");
			return student;
		}
		else{
		
		studentData.put(student.getId(), student);
		student.setMsg("Created a new entry with id "+student.getId());
		return student;
		}
	}
	
	
	@RequestMapping(value = "/students/{id}", method = RequestMethod.DELETE)
	public @ResponseBody Student deleteEmployee(@PathVariable("id") int studentId) {
		
		
		if(studentData.containsKey(studentId)){
		Student student = studentData.get(studentId);
		studentData.remove(studentId);
		student.setMsg("Deleted an entry with id "+student.getId());
		return student;
		}
		else{
			Student student=new Student();
			student.setMsg("Student id not found");
			return student;
		}
	}
	
	//Updating the hashmap
		@RequestMapping(value = "/students/{id}",method = RequestMethod.PUT)
		public @ResponseBody Student updateEmployee(@RequestBody Student new_student,@PathVariable("id") int id) {
			
			if(studentData.containsKey(id)){
			Student student=studentData.get(id);
			student.setName(new_student.getName());
			student.setAge(new_student.getAge());
			student.setId(new_student.getId());
			studentData.put(student.getId(), student);
			student.setMsg("Updated an entry with id "+ id);
			return student;
			}
			else{
				Student student=new Student();
				student.setMsg("Student id not found");
				return student;
			}
			
		}
	
	


}
