import java.util.Arrays;

public class zeroMax {
	public static int[] FindZeroMax(int[] nums) {
		  int max;
			for(int i = 0; i < nums.length - 1; i++)
			{
				if(nums[i] == 0)
				{
					max = 0;
					for(int k = i + 1; k < nums.length; k++)
					{
						if(nums[k] > max && nums[k] % 2 == 1)
							max = nums[k];
					}
					if(max != 0)
						nums[i] = max;
				}
			}
			return nums;
		}

	public static void main(String args[])
	{
		int[] arr={0,0,5,4,9,0,7};
		System.out.println(Arrays.toString(FindZeroMax(arr)));
	}
	
}
