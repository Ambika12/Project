package com.training.daoimpl;
import java.util.List;



import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.training.dao.EmployeeDAO;
import com.training.mapper.EmployeeMapper;
import com.training.model.Employees;


public class EmployeesJDBCTemplate implements EmployeeDAO {
	
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }

	
	   
	   public List<Employees> getEmployees(String bloodGroup) {
		   
		   List<Employees> emp=null;
		   try
		   {
		      String SQL = "select * from BGDatabase where bloodGroup = ?";
		       emp = jdbcTemplateObject.query(SQL, new Object[]{bloodGroup}, new EmployeeMapper());
		      
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
		   return emp;
	   }



	public void postEmployees(Employees emp) {
		jdbcTemplateObject.update("insert into BGDatabase values("+emp.getId()+",'"+emp.getName()+"','"+emp.getPassword()+"','"+emp.getEmail()+"','"+emp.getPhoneNo()+"','"+emp.getBloodGroup()+"')");
	}



	public void updateEmployees(Employees emp) {
		
		 String SQL = "update BGDatabase set phoneNo = ? where id =? ";
	      jdbcTemplateObject.update(SQL,emp.getPhoneNo(),emp.getId());
	}



	public void deleteEmployees(Integer id) {
		String SQL = "delete from BGDatabase where id = ?";
	      jdbcTemplateObject.update(SQL, id);
		
	}



	public List<Employees> getallEmployees() {
		List<Employees> employee=null;
		   try
		   {
		      String SQL = "select * from BGDatabase";
		      employee = jdbcTemplateObject.query(SQL, new Object[]{}, new EmployeeMapper());
		      
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
		   return employee;
	   
	
	}
}




	