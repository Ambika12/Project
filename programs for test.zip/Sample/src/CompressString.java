
import java.util.Scanner;

public class CompressString {

       public static void main(String[] args) {
              Scanner sc=new Scanner(System.in);
              String s=sc.next();
              String res="";
              int count=0,j=0;
              int len=s.length();
              for(int i=0;i<len-1;i++) {
                     count=0;
                     if(s.charAt(i)!=s.charAt(i+1)) {
                           res+=s.substring(i,i+1);   
                     }
                     else {
                           count++;
                           for(j=i+1;j<=len-1;j++) {
                                  if(s.charAt(i)==s.charAt(j)) 
                                         count++;
                              else {     
                                                break;
                              }
                                  
                           }
                           res+=s.substring(j-1,j);
                           res+=Integer.toString(count);
                           i=j-1;
                           }
              }
              if(s.charAt(len-2)!=s.charAt(len-1))
                     res+=s.substring(len-1);
              System.out.println(res);
       }
}


