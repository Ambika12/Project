import java.util.ArrayList;
import java.util.List;

public class EmailId {
	public static void main(String[] a) {
		List<Employee> emps = new ArrayList<Employee>();
		Employee e = new Employee();
		e.setFirstName("Ambika");
		e.setLastname("Rajendran");
		e.setRawdata("12011996");
		emps.add(e);
		for(Employee e1: emps){
			String emailID=e.getLastname()+e.getFirstName().substring(0,1).toUpperCase()+e.getRawdata().substring(0,4)+"@inautix.com";
			System.out.println(emailID);		
		}

	}
}

	

class Employee {

	private String firstName;

	private String lastname;

	private String rawdata;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getRawdata() {
		return rawdata;
	}

	public void setRawdata(String rawdata) {
		this.rawdata = rawdata;
	}

}

