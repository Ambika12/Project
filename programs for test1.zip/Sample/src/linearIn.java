
public class linearIn {
	public static boolean FindLinearIn(int[] outer, int[] inner) {
		  int numFound = 0;
		  if(inner.length == 0) {
		     return true;
		  }
		 
		  int k = 0;
		  for(int i = 0; i < outer.length; i++)
		  
		  {
		     if(outer[i] == inner[k])
		     {
		        numFound++;
		        k++;
		       } 
		     
		     }
		    
		     if(numFound == inner.length)
		        return true;
		
		return false;
	}
	
	public static void main(String args[])
	
	{
		
		int[] arr1={1,2,3,4};
		int[] arr2={1,2,4};
		System.out.println(FindLinearIn(arr1,arr2));
	}
}
