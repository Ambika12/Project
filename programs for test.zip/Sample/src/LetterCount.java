import java.io.*;
import java.util.*;

public class LetterCount {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String str= sc.next();
          sc.close();
           char a[] = str.toCharArray();
           
           int hash[]= new int[26];  int n= str.length();
           
           //count the occurrences of each letter
           
           
           for(int i=0; i<n; i++)
           {
                  hash[a[i] -'a']++;                
           }
           for(int i=0; i<n; i++)
           {
                  if(a[i]!='\0' && hash[a[i]-'a']!=-1 ) 
                  {
                	  if(hash[a[i]-'a']==1) 
                               System.out.print(""+a[i]+1);  else 
                        System.out.print(""+a[i] + hash[a[i]-'a']);
                        hash[a[i]-'a']=-1;
                  }
                  }
           }
    }

