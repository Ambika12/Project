package com.bny.bean;

import java.sql.Date;

public class Employee 
{
	/* EMP_ID   NUMBER PRIMARY KEY
	 EMP_NAME   VARCHAR (120)
	 DOB DATE
	 DESIGNATION VARCHAR (120)
	 DEPT_ID   NUMBER FOREIGN KEY */
	int emp_id;
	String emp_name;
	Date DOB;
	String designation;
	int dept_id;
	
	
	
	public int getEmp_id()
	{
		return emp_id;
	}
	public void setEmp_id(int emp_id)
	{
		this.emp_id = emp_id;
	}
	public String getEmp_name()
	{
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	

}
