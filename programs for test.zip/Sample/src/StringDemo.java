import java.lang.*;

public class StringDemo {

   public static void main(String[] args) {

      String str = "This is tutorials point";
      String substr = "";
    
      // prints the substring after index 7
      substr = str.substring(0,0);
      System.out.println("substring = " + substr);

      // prints the substring after index 0 i.e whole string gets printed
      substr = str.substring(0);
      System.out.println("substring = " + substr);
   }
}