import java.util.Scanner;

public class Fentabulous {

       public static void main(String[] args) {
              Scanner sc=new Scanner(System.in);// 2358
              int a[]=new int[4];
              for(int i=0;i<4;i++) {
                     a[i]=sc.nextInt();
                                         
              }
              int sum=a[0],flag=0,mul=a[0],flag1=0;
              for(int i=1;i<3;i++) {
                     sum=sum+a[i];
                     
                     if(sum<a[i+1]) {
                           //System.out.println("sum"+sum);
                           flag=1;
                     }
                     else {
                           flag=0;
                           
                           break;
                     }
              }
              for(int i=1;i<3;i++) {
                     mul=mul*a[i];
                     
                     if(mul<a[i+1]) {
                           //System.out.println("mul"+mul);
                           flag1=1;
                     }
                     else {
                           flag1=0;
                           break;
                     }
              }
              if(flag==1  && flag1==0) 
                     System.out.println("Fantastic");
              else if(flag==0  && flag1==1) 
                     System.out.println("Fabulous");
              else if(flag==1  && flag1==1) 
                     System.out.println("Fantabulous");
              else
                     System.out.println("None");
       }

}

