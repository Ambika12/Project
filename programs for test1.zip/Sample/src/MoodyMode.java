import java.util.*;

public class MoodyMode {

       public static void main(String[] args) {
              
              int[] arr = {200,100,50,2};
              
              TreeSet<Integer> set = new TreeSet<Integer>(); 
              TreeSet<Integer> dset = new TreeSet<Integer>();
              
              for(int i=0; i<arr.length; i++)
              {
                     if(set.contains(arr[i]))
                     {
                           dset.add(arr[i]);
                     }
                     else
                     {
                           set.add(arr[i]);
                     }
              }
              if(dset.size()==0)
              {
            	  System.out.println("Moody mode"); 
              }
              
              else
              {
            	  System.out.println(dset);
              }
              
       }

}
