
public class mixString {
	public static String mixString(String a, String b) {
		  int aLen = a.length();
		  int bLen = b.length();

		  int max = Math.max(aLen, bLen);

		  String word = "";

		    for (int i = 0; i < max; i++) {

		    if (i < aLen)

		      word += a.charAt(i);

		    if (i < bLen)

		      word += b.charAt(i);
		  }

		  return word;

		}
	
	public static void main(String args[])
	{
		String s="abcdef";
		String s1="hijklm";
		System.out.println(mixString(s,s1));
	}

}
