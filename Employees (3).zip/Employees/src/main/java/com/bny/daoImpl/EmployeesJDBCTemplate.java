package com.bny.daoImpl;

import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import com.bny.bean.Department;
import com.bny.bean.Employee;
import com.bny.dao.IEmployeeDao;
import com.bny.rowmapper.EmployeeMapper;


public class EmployeesJDBCTemplate implements IEmployeeDao 
{
	
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	   
	   public void setDataSource(DataSource dataSource) 
	   {
	      this.dataSource = dataSource;
	      this.jdbcTemplate = new JdbcTemplate(dataSource);
	   }

	   //view
		public Employee getEmployeeById(int emp_id)
		{
			String sql="select * from employee_xbbnhhi where emp_id="+emp_id;
			
			Employee employee=jdbcTemplate.queryForObject(sql,new EmployeeMapper());
			
			return employee;
		}
		
		//view all employees
		
	   public  List<Employee> getEmployees() 
		{          
		   	  String SQL = "select * from employee_xbbnhhi";

              Employee emp=jdbcTemplate.queryForObject(SQL,new EmployeeMapper());

              List<Employee> empList = new ArrayList<Employee>();

              empList.add(emp); 

              return empList; 
        }


		
		//insert
		
		public Employee insertEmployee(Employee employee)
		{
			Department dept=new Department();
			String sql="insert into employee_xbbnhhi values("+employee.getEmp_id()+",'"+employee.getEmp_name()+"','"+employee.getDOB()+"','"+employee.getDesignation()+"',"+employee.getDept_id()+" ,'"+dept.getDept_name()+"')";
			jdbcTemplate.update(sql);
			return employee;
		}

		//delete
		
		public Employee deleteEmployee(int emp_id) 
		{
			Employee emp=new Employee();

			String sql = "delete from employee_xbbnhhi where emp_id = ?";
			jdbcTemplate.update(sql);
			return emp;
			
		}
		
		//update

		public Employee updateEmployee(int emp_id)
		{
			 Employee emp=new Employee();
			 String sql= "update Employee_xbbnhhi set designation= ? where emp_id =? ";
		     jdbcTemplate.update(sql,emp.getDesignation(),emp.getEmp_id());
		     return emp;
		}

}

	