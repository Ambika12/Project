import java.util.*;
public class Modifiedprice 
{
       public static void main(String args[])
       {
              String s1[]={"Rice","Wheat","Sugar","Salt"};
              float f1[]={20.5f,45.7f,43.4f,22.3f};
              String s2[]={"Rice","Wheat"};
              float f2[]={22.5f,6.4f};
              int count=mapping(s1,f1,s2,f2);
              System.out.println(count);
              
       }      
       private static int mapping(String[] s1,float[] f1,String[] s2,float[] f2)
       {
              int count=0;
              HashMap<String,Float> map1=new HashMap<String,Float>();
              for(int i=0;i<s1.length;i++)
              {
              map1.put(s1[i],f1[i]);
           }
              System.out.println(map1);
              
              HashMap<String,Float> map2=new HashMap<String,Float>();
              for(int j=0;j<s2.length;j++)
              {
                     map2.put(s2[j],f2[j]);
              }
              System.out.println(map2);
              
              for(int k=0;k<s2.length;k++)
              {
                     if(map1.containsKey(s2[k]))
                     {
                           String temp=s2[k];
                           float f11=map1.get(temp);
                           float f22=map2.get(temp);
                     
                     if(f11!=f22)
                     {
                           count++;
                     }
                  }
              }
                     return count; 
              }
}

