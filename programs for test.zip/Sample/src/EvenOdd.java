import java.io.*;
import java.util.Arrays;

class EvenOdd
{
	public static void main(String args[])
	{
		int[] arr={0,1,0,1};
		int[] result=evenOdd(arr);
		System.out.println(Arrays.toString(result));
	}



public static int[] evenOdd(int[] nums) {
 int temp;
  int evenIndex = 0;
	for(int i = 0; i < nums.length; i++)
	{
		if(nums[i] % 2 == 0)
		{
			temp = nums[i];
			nums[i] = nums[evenIndex];
			nums[evenIndex] = temp;
			evenIndex++;
		}
	}
	return nums;
}

}
