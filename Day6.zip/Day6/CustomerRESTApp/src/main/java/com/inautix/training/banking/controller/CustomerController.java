package com.inautix.training.banking.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.inautix.training.banking.dao.CustomerDAO;
import com.inautix.training.banking.domain.Customer;



@RestController 
public class CustomerController {
	
	@Autowired
	private CustomerDAO customerDao;
	
	
		
	@RequestMapping(value = "/customers", method = RequestMethod.POST)
	public @ResponseBody Customer createCustomer(@RequestBody Customer customer){
		System.out.println("inside CustomerController createCustomer");
		
		customerDao.createCustomer(customer);
		
		return  customer;
		
	}
	
	@RequestMapping(value = "/customers/{customerId}", method = RequestMethod.GET)
	public @ResponseBody Customer getCustomerDetails(@PathVariable  int customerId){
		
	    Customer customer = null;
	    customer= customerDao.getCustomerDetails(customerId);
		
	    return customer;  
	    
	}
	
    @RequestMapping(value="/customers/{customerId}",method = RequestMethod.PUT)  
	public @ResponseBody Customer updateCustomer(@RequestBody Customer newCustomer,@PathVariable int customerId){
		System.out.println("inside customercontroller updateCustomer");
		
		Customer customer =customerDao.getCustomerDetails(customerId);
		
		customer.setCustomerName(newCustomer.getCustomerName());
		customer.setLocation(newCustomer.getLocation());
		
		customerDao.updateCustomer(customer);
		
		return customer;  
		
	}
	
	
    @RequestMapping(value="/customers/{customerId}",method = RequestMethod.DELETE) 
    public @ResponseBody Customer deleteCustomer(@PathVariable int customerId){
		
    	Customer customer =customerDao.getCustomerDetails(customerId) ;
		customerDao.deleteCustomer(customerId);
		
		return customer;  
		
	}
	
    @RequestMapping(value = "/customers", method = RequestMethod.GET)
	public @ResponseBody List<Customer> getAllCustomers(){
		List customerList = null;
		
		
		customerList = customerDao.getAllCustomer();
		
		
		return customerList; 
		
	}
	
	
		
	

}
