import java.util.Arrays;

public class Arrange {

       public static void main(String[] args) 
       {
              
              String str = "I am a dog ";
              str=str.replace('.', ' ');
              str = str.toLowerCase();
              
              String temp1="";
              String[] s = str.split("\\s");
              for(int i=0;i<s.length;i++)
              {
                    // s[i]=s[i].substring(0,1).toUpperCase()+s[i].substring(1);
                     System.out.println(s[i] +"----->"+s[i].length());
              }
              for(int i=0; i<s.length; i++)
              {
                     
                     for(int j=i+1;j<s.length;j++)
                     {
                           if(s[i].length()>s[j].length())
                           {
                                  temp1=s[i];
                                  s[i]=s[i+1];
                                  s[i+1]=temp1;
                           }
                     }
              }
              
              String result=Arrays.toString(s);
              result=result.substring(1,result.length()-1).replaceAll(",","");
              System.out.println(result.substring(0,1).toUpperCase()+result.substring(1)+".");

       }

}
